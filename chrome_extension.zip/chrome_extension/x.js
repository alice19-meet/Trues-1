var x =1;

x = x +2

console.log(x)
